import { useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  Ban,
  BarChart3,
  Check,
  Clipboard,
  Database,
  FileText,
  Gauge,
  KeyRound,
  LayoutDashboard,
  LockKeyhole,
  LogIn,
  PlugZap,
  RefreshCcw,
  Search,
  Server,
  Settings,
  ShieldCheck,
  UserPlus,
  UserRound,
  UsersRound,
} from 'lucide-react'
import './App.css'

type View = 'overview' | 'pool' | 'members' | 'activation' | 'setup' | 'monitor'
type Role = 'member' | 'admin'

type PoolAccount = {
  name: string
  plan: string
  capacity: number
  used: number
  status: 'normal' | 'standby' | 'limited'
  latency: string
  note: string
}

type GroupQuota = {
  name: string
  multiplier: string
  access: string
  capacity: number
  used: number
  status: string
}

type Member = {
  name: string
  role: string
  status: 'active' | 'paused'
  group: string
  keyLabel: string
  inviteCode: string
  quotaLimit: number
  quotaUsed: number
  todayUsed: number
  requestCount: number
  concurrency: number
  lastSeen: string
}

type InviteCode = {
  code: string
  status: 'unused' | 'used' | 'disabled'
  owner: string
  group: string
  createdAt: string
  usedAt: string
}

type RequestLog = {
  time: string
  user: string
  group: string
  model: string
  tokens: string
  quota: string
  status: string
}

type ActivationPayload = {
  code: string
  name: string
  group: string
}

type ActivationResult = {
  ok: boolean
  key?: string
  error?: string
}

const apiBaseUrl = 'http://127.0.0.1:8787/v1'
const productionApiBaseUrl = 'https://api.scgk114.com/v1'
const warningPercent = 80

const poolAccounts: PoolAccount[] = [
  {
    name: 'OpenAI Pro 主池',
    plan: 'Pro 20x',
    capacity: 20,
    used: 6.8,
    status: 'normal',
    latency: '1.6s',
    note: '默认承载 Codex 与文本调用',
  },
  {
    name: 'OpenAI Pro 备用池',
    plan: 'Pro 20x',
    capacity: 20,
    used: 1.9,
    status: 'standby',
    latency: '1.9s',
    note: '主池接近阈值时自动切换',
  },
  {
    name: 'OpenAI Plus 轻量池',
    plan: 'Plus',
    capacity: 5,
    used: 0.7,
    status: 'standby',
    latency: '2.4s',
    note: '低优先级任务与演示备用',
  },
]

const groupQuotas: GroupQuota[] = [
  {
    name: 'GPT1',
    multiplier: '1x',
    access: 'Codex、问答、代码改写',
    capacity: 26,
    used: 7.2,
    status: '默认开放',
  },
  {
    name: 'image-2 生图专用',
    multiplier: '1x',
    access: '图片与高成本任务',
    capacity: 5,
    used: 0.8,
    status: '按需开放',
  },
  {
    name: 'research-heavy',
    multiplier: '2x',
    access: '长上下文、批量模拟',
    capacity: 8,
    used: 1.4,
    status: '管理员审批',
  },
]

const dailyUsage = [
  { day: '07-03', codex: 0.8, chat: 0.3, image: 0.1 },
  { day: '07-04', codex: 1.2, chat: 0.4, image: 0.1 },
  { day: '07-05', codex: 0.7, chat: 0.2, image: 0.0 },
  { day: '07-06', codex: 1.9, chat: 0.6, image: 0.2 },
  { day: '07-07', codex: 1.5, chat: 0.5, image: 0.2 },
  { day: '07-08', codex: 2.1, chat: 0.8, image: 0.3 },
  { day: '07-09', codex: 1.4, chat: 0.5, image: 0.1 },
]

const initialMembers: Member[] = [
  {
    name: '演示成员 A',
    role: '博士生',
    status: 'active',
    group: 'GPT1',
    keyLabel: 'sk-scgk114-a1...9c2f',
    inviteCode: 'SCGK-A7K2',
    quotaLimit: 3,
    quotaUsed: 1.24,
    todayUsed: 0.18,
    requestCount: 184,
    concurrency: 2,
    lastSeen: '11:26',
  },
  {
    name: '演示成员 B',
    role: '硕士生',
    status: 'active',
    group: 'GPT1',
    keyLabel: 'sk-scgk114-b7...44ae',
    inviteCode: 'SCGK-Q4M8',
    quotaLimit: 3,
    quotaUsed: 0.78,
    todayUsed: 0.11,
    requestCount: 119,
    concurrency: 1,
    lastSeen: '10:54',
  },
  {
    name: '图像任务席位',
    role: '共享席位',
    status: 'paused',
    group: 'image-2 生图专用',
    keyLabel: 'sk-scgk114-img...1d91',
    inviteCode: 'SCGK-Z0R1',
    quotaLimit: 1.5,
    quotaUsed: 0,
    todayUsed: 0,
    requestCount: 0,
    concurrency: 1,
    lastSeen: '-',
  },
]

const initialInviteCodes: InviteCode[] = [
  {
    code: 'SCGK-A7K2',
    status: 'used',
    owner: '演示成员 A',
    group: 'GPT1',
    createdAt: '07-01',
    usedAt: '07-02',
  },
  {
    code: 'SCGK-Q4M8',
    status: 'used',
    owner: '演示成员 B',
    group: 'GPT1',
    createdAt: '07-01',
    usedAt: '07-04',
  },
  {
    code: 'SCGK-N9P3',
    status: 'unused',
    owner: '预留名额',
    group: 'GPT1',
    createdAt: '07-09',
    usedAt: '-',
  },
  {
    code: 'SCGK-X2D6',
    status: 'disabled',
    owner: '已作废',
    group: 'research-heavy',
    createdAt: '07-05',
    usedAt: '-',
  },
]

const recentRequests: RequestLog[] = [
  {
    time: '11:26',
    user: '演示成员 A',
    group: 'GPT1',
    model: 'gpt-5.5',
    tokens: '18.2k / 4.1k',
    quota: '0.08x',
    status: '成功',
  },
  {
    time: '10:54',
    user: '演示成员 B',
    group: 'GPT1',
    model: 'gpt-5.5',
    tokens: '9.8k / 2.2k',
    quota: '0.04x',
    status: '成功',
  },
  {
    time: '09:42',
    user: '演示成员 A',
    group: 'research-heavy',
    model: 'gpt-5.5',
    tokens: '43.7k / 11.1k',
    quota: '0.22x',
    status: '管理员放行',
  },
  {
    time: '09:15',
    user: '演示成员 B',
    group: 'GPT1',
    model: 'gpt-5.5',
    tokens: '12.4k / 0',
    quota: '0.03x',
    status: '取消',
  },
]

function App() {
  const [activeView, setActiveView] = useState<View>(() => getViewFromHash())
  const [role, setRole] = useState<Role>('admin')
  const [members, setMembers] = useState<Member[]>(initialMembers)
  const [inviteCodes, setInviteCodes] = useState<InviteCode[]>(initialInviteCodes)
  const [activationKey, setActivationKey] = useState('sk-scgk114-new...7f3d')
  const [copied, setCopied] = useState('')
  const [query, setQuery] = useState('')

  useEffect(() => {
    const syncHash = () => setActiveView(getViewFromHash())

    window.addEventListener('hashchange', syncHash)
    return () => window.removeEventListener('hashchange', syncHash)
  }, [])

  const totals = useMemo(() => {
    const capacity = poolAccounts.reduce((sum, account) => sum + account.capacity, 0)
    const used = poolAccounts.reduce((sum, account) => sum + account.used, 0)
    const todayUsed = members.reduce((sum, member) => sum + member.todayUsed, 0)
    const requestCount = members.reduce((sum, member) => sum + member.requestCount, 0)
    const activeMembers = members.filter((member) => member.status === 'active').length
    const activePools = poolAccounts.filter((account) => account.status !== 'limited').length

    return {
      capacity,
      used,
      remaining: Math.max(capacity - used, 0),
      usagePercent: Math.min((used / Math.max(capacity, 1)) * 100, 100),
      todayUsed,
      requestCount,
      activeMembers,
      activePools,
      inviteCount: inviteCodes.length,
      usedInviteCount: inviteCodes.filter((code) => code.status === 'used').length,
      unusedInviteCount: inviteCodes.filter((code) => code.status === 'unused').length,
    }
  }, [members, inviteCodes])

  const currentMember = members[0]
  const filteredMembers = members.filter((member) =>
    member.name.toLowerCase().includes(query.toLowerCase()),
  )

  const copyText = async (value: string, token: string) => {
    await navigator.clipboard.writeText(value)
    setCopied(token)
    window.setTimeout(() => setCopied(''), 1600)
  }

  const navigate = (view: View) => {
    setActiveView(view)
    window.history.replaceState(null, '', `#${view}`)
  }

  const generateInviteCode = () => {
    const code = createInviteCode(inviteCodes)
    setInviteCodes((current) => [
      {
        code,
        status: 'unused',
        owner: '今日内测名额',
        group: 'GPT1',
        createdAt: '07-09',
        usedAt: '-',
      },
      ...current,
    ])
    setCopied('invite-generated')
    navigate('activation')
    window.setTimeout(() => setCopied(''), 1600)
  }

  const activateInvite = ({ code, name, group }: ActivationPayload): ActivationResult => {
    const invite = inviteCodes.find((item) => item.code === code)

    if (!invite) {
      return { ok: false, error: '没有找到这个登录码，请确认大小写。' }
    }

    if (invite.status !== 'unused') {
      return { ok: false, error: '这个登录码已经使用或停用，请重新生成。' }
    }

    const key = createDemoKey(code)
    const trimmedName = name.trim() || '今日内测成员'

    setMembers((current) => [
      {
        name: trimmedName,
        role: '内测成员',
        status: 'active',
        group,
        keyLabel: maskKey(key),
        inviteCode: code,
        quotaLimit: 3,
        quotaUsed: 0,
        todayUsed: 0,
        requestCount: 0,
        concurrency: 1,
        lastSeen: '刚刚',
      },
      ...current,
    ])

    setInviteCodes((current) =>
      current.map((item) =>
        item.code === code
          ? {
              ...item,
              status: 'used',
              owner: trimmedName,
              group,
              usedAt: '刚刚',
            }
          : item,
      ),
    )
    setActivationKey(key)

    return { ok: true, key }
  }

  return (
    <div className="app-shell">
      <aside className="sidebar" aria-label="主导航">
        <div className="brand">
          <div className="brand-mark" aria-hidden="true">
            S
          </div>
          <div>
            <strong>scgk114</strong>
            <span>课题组订阅额度池</span>
          </div>
        </div>

        <nav className="nav-list">
          <NavButton
            icon={<LayoutDashboard size={18} />}
            label="总览"
            active={activeView === 'overview'}
            onClick={() => navigate('overview')}
          />
          <NavButton
            icon={<Database size={18} />}
            label="额度池"
            active={activeView === 'pool'}
            onClick={() => navigate('pool')}
          />
          <NavButton
            icon={<UsersRound size={18} />}
            label="成员"
            active={activeView === 'members'}
            onClick={() => navigate('members')}
          />
          <NavButton
            icon={<LogIn size={18} />}
            label="登录码"
            active={activeView === 'activation'}
            onClick={() => navigate('activation')}
          />
          <NavButton
            icon={<PlugZap size={18} />}
            label="接入"
            active={activeView === 'setup'}
            onClick={() => navigate('setup')}
          />
          <NavButton
            icon={<Activity size={18} />}
            label="状态"
            active={activeView === 'monitor'}
            onClick={() => navigate('monitor')}
          />
        </nav>

        <div className="sidebar-footer">
          <div className="status-pill">
            <span className="status-dot" />
            内部试运行
          </div>
          <p>www.scgk114.com</p>
        </div>
      </aside>

      <main className="workspace">
        <header className="topbar">
          <div>
            <p className="eyebrow">订阅池 MVP</p>
            <h1>{getViewTitle(activeView)}</h1>
          </div>

          <div className="topbar-actions">
            <div className="segmented" aria-label="角色切换">
              <button
                type="button"
                className={role === 'member' ? 'active' : ''}
                onClick={() => setRole('member')}
              >
                <UserRound size={16} />
                成员视图
              </button>
              <button
                type="button"
                className={role === 'admin' ? 'active' : ''}
                onClick={() => setRole('admin')}
              >
                <ShieldCheck size={16} />
                管理视图
              </button>
            </div>
            <button className="icon-button" type="button" title="刷新数据">
              <RefreshCcw size={18} />
            </button>
            <button className="icon-button" type="button" title="系统设置">
              <Settings size={18} />
            </button>
          </div>
        </header>

        {activeView === 'overview' && (
          <Overview role={role} currentMember={currentMember} totals={totals} />
        )}
        {activeView === 'pool' && <QuotaPool totals={totals} />}
        {activeView === 'members' && (
          <Members
            members={filteredMembers}
            inviteCodes={inviteCodes}
            role={role}
            query={query}
            setQuery={setQuery}
            copied={copied}
            onCopy={copyText}
            onGenerateInvite={generateInviteCode}
          />
        )}
        {activeView === 'activation' && (
          <Activation
            activationKey={activationKey}
            copied={copied}
            inviteCodes={inviteCodes}
            onActivate={activateInvite}
            onCopy={copyText}
          />
        )}
        {activeView === 'setup' && <Setup copied={copied} onCopy={copyText} />}
        {activeView === 'monitor' && <Monitor />}
      </main>
    </div>
  )
}

function NavButton({
  icon,
  label,
  active,
  onClick,
}: {
  icon: ReactNode
  label: string
  active: boolean
  onClick: () => void
}) {
  return (
    <button
      className={active ? 'nav-button active' : 'nav-button'}
      type="button"
      onClick={onClick}
      title={label}
    >
      {icon}
      <span>{label}</span>
    </button>
  )
}

function Overview({
  role,
  currentMember,
  totals,
}: {
  role: Role
  currentMember: Member
  totals: {
    capacity: number
    used: number
    remaining: number
    usagePercent: number
    todayUsed: number
    requestCount: number
    activeMembers: number
    inviteCount: number
    usedInviteCount: number
    unusedInviteCount: number
  }
}) {
  const personalPercent = Math.min(
    (currentMember.quotaUsed / Math.max(currentMember.quotaLimit, 1)) * 100,
    100,
  )

  return (
    <section className="view-stack">
      <div className="metrics-grid">
        <MetricCard
          icon={<Database size={19} />}
          label={role === 'admin' ? '总订阅额度' : '个人月度额度'}
          value={
            role === 'admin'
              ? `${formatQuota(totals.capacity)}`
              : `${formatQuota(currentMember.quotaLimit)}`
          }
          detail={
            role === 'admin'
              ? `剩余 ${formatQuota(totals.remaining)}`
              : `剩余 ${formatQuota(currentMember.quotaLimit - currentMember.quotaUsed)}`
          }
        />
        <MetricCard
          icon={<Gauge size={19} />}
          label={role === 'admin' ? '全组使用率' : '个人使用率'}
          value={
            role === 'admin'
              ? `${Math.round(totals.usagePercent)}%`
              : `${Math.round(personalPercent)}%`
          }
          detail={
            role === 'admin'
              ? `本月已用 ${formatQuota(totals.used)}`
              : `本月已用 ${formatQuota(currentMember.quotaUsed)}`
          }
        />
        <MetricCard
          icon={<Activity size={19} />}
          label="本月请求"
          value={`${role === 'admin' ? totals.requestCount : currentMember.requestCount}`}
          detail="按个人 Key 汇总"
        />
        <MetricCard
          icon={<LogIn size={19} />}
          label="登录码"
          value={`${totals.usedInviteCount}/${totals.inviteCount}`}
          detail={`未使用 ${totals.unusedInviteCount} 个`}
        />
      </div>

      <div className="overview-layout">
        <section className="panel usage-panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">七日趋势</p>
              <h2>订阅额度消耗</h2>
            </div>
            <span className="soft-badge">按倍率折算</span>
          </div>
          <UsageChart />
          <ChartLegend />
        </section>

        <section className="panel budget-panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">总池</p>
              <h2>本月使用率</h2>
            </div>
            <span className="soft-badge">{Math.round(totals.usagePercent)}%</span>
          </div>
          <div className="quota-track">
            <span style={{ width: `${totals.usagePercent}%` }} />
          </div>
          <div className="budget-copy">
            <strong>{formatQuota(totals.used)}</strong>
            <span> / {formatQuota(totals.capacity)}</span>
          </div>
          <div className="policy-list compact">
            <PolicyItem label="默认分组" value="GPT1 · 1x" />
            <PolicyItem label="成员并发" value="1-2 路" />
            <PolicyItem label="触顶动作" value="提醒后切备用池" />
          </div>
        </section>
      </div>

      <section className="panel">
        <div className="section-heading">
          <div>
            <p className="eyebrow">元数据</p>
            <h2>最近请求</h2>
          </div>
          <span className="soft-badge">不保存正文</span>
        </div>
        <DataTable
          columns={['时间', '成员', '分组', '模型', 'Tokens', '额度', '状态']}
          rows={recentRequests.map((request) => [
            request.time,
            request.user,
            request.group,
            request.model,
            request.tokens,
            request.quota,
            request.status,
          ])}
        />
      </section>
    </section>
  )
}

function QuotaPool({
  totals,
}: {
  totals: {
    capacity: number
    used: number
    remaining: number
    usagePercent: number
    activePools: number
  }
}) {
  return (
    <section className="view-stack">
      <div className="notice-band">
        <Database size={20} />
        <div>
          <strong>页面只展示订阅额度池与使用率</strong>
          <span>
            Pro、Plus 等上游订阅统一进入额度池，再通过分组和个人 Key 分配给成员。
          </span>
        </div>
      </div>

      <div className="metrics-grid">
        <MetricCard
          icon={<Server size={19} />}
          label="上游池数量"
          value={`${poolAccounts.length}`}
          detail={`${totals.activePools} 个可调度`}
        />
        <MetricCard
          icon={<Database size={19} />}
          label="总额度"
          value={formatQuota(totals.capacity)}
          detail="含主池与备用池"
        />
        <MetricCard
          icon={<BarChart3 size={19} />}
          label="已用额度"
          value={formatQuota(totals.used)}
          detail={`剩余 ${formatQuota(totals.remaining)}`}
        />
        <MetricCard
          icon={<Gauge size={19} />}
          label="总使用率"
          value={`${Math.round(totals.usagePercent)}%`}
          detail="超过 80% 触发提醒"
        />
      </div>

      <section className="panel">
        <div className="section-heading">
          <div>
            <p className="eyebrow">上游订阅</p>
            <h2>额度池状态</h2>
          </div>
          <span className="soft-badge">管理员可见</span>
        </div>
        <div className="member-grid">
          {poolAccounts.map((account) => (
            <PoolCard account={account} key={account.name} />
          ))}
        </div>
      </section>

      <section className="panel">
        <div className="section-heading">
          <div>
            <p className="eyebrow">分组</p>
            <h2>倍率与访问范围</h2>
          </div>
          <span className="soft-badge">用于分配能力</span>
        </div>
        <DataTable
          columns={['分组', '倍率', '访问范围', '额度', '已用', '使用率', '状态']}
          rows={groupQuotas.map((group) => [
            group.name,
            group.multiplier,
            group.access,
            formatQuota(group.capacity),
            formatQuota(group.used),
            `${Math.round((group.used / group.capacity) * 100)}%`,
            group.status,
          ])}
        />
      </section>
    </section>
  )
}

function Members({
  members,
  inviteCodes,
  role,
  query,
  setQuery,
  copied,
  onCopy,
  onGenerateInvite,
}: {
  members: Member[]
  inviteCodes: InviteCode[]
  role: Role
  query: string
  setQuery: (value: string) => void
  copied: string
  onCopy: (value: string, token: string) => void
  onGenerateInvite: () => void
}) {
  return (
    <section className="view-stack">
      <div className="toolbar">
        <label className="search-field">
          <Search size={17} />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="搜索成员"
          />
        </label>
        <button className="primary-button" type="button" onClick={onGenerateInvite}>
          <UserPlus size={17} />
          {copied === 'invite-generated' ? '已生成' : '生成登录码'}
        </button>
      </div>

      <section className="panel">
        <div className="section-heading">
          <div>
            <p className="eyebrow">成员</p>
            <h2>个人 Key 与额度</h2>
          </div>
          <span className="soft-badge">
            {role === 'admin' ? '管理员视图' : '成员视图'}
          </span>
        </div>
        <div className="member-grid">
          {members.map((member) => (
            <MemberCard member={member} role={role} key={member.keyLabel} />
          ))}
        </div>
      </section>

      <section className="panel">
        <div className="section-heading">
          <div>
            <p className="eyebrow">登录码</p>
            <h2>发码与激活状态</h2>
          </div>
          <span className="soft-badge">用过即失效</span>
        </div>
        <div className="invite-grid">
          {inviteCodes.map((invite) => (
            <InviteCard
              copied={copied}
              invite={invite}
              key={invite.code}
              onCopy={onCopy}
            />
          ))}
        </div>
      </section>
    </section>
  )
}

function Activation({
  activationKey,
  copied,
  inviteCodes,
  onActivate,
  onCopy,
}: {
  activationKey: string
  copied: string
  inviteCodes: InviteCode[]
  onActivate: (payload: ActivationPayload) => ActivationResult
  onCopy: (value: string, token: string) => void
}) {
  const firstUnusedCode =
    inviteCodes.find((invite) => invite.status === 'unused')?.code ?? ''
  const [code, setCode] = useState(firstUnusedCode)
  const [name, setName] = useState('今日内测成员')
  const [group, setGroup] = useState('GPT1')
  const [message, setMessage] = useState('')

  useEffect(() => {
    if (!code && firstUnusedCode) {
      setCode(firstUnusedCode)
    }
  }, [code, firstUnusedCode])

  const handleActivate = () => {
    const result = onActivate({
      code: code.trim(),
      group,
      name: name.trim(),
    })

    if (!result.ok) {
      setMessage(result.error ?? '激活失败，请检查登录码。')
      return
    }

    setMessage('已生成演示 Key，并把成员加入列表。真实上线时这里会调用后端接口。')
  }

  return (
    <section className="view-stack">
      <div className="activation-layout">
        <section className="panel activation-card">
          <div className="section-heading">
            <div>
              <p className="eyebrow">成员入口</p>
              <h2>登录码激活</h2>
            </div>
            <span className="soft-badge">一次性</span>
          </div>
          <label>
            登录码
            <input value={code} onChange={(event) => setCode(event.target.value)} />
          </label>
          <label>
            姓名或备注
            <input value={name} onChange={(event) => setName(event.target.value)} />
          </label>
          <label>
            默认分组
            <select value={group} onChange={(event) => setGroup(event.target.value)}>
              {groupQuotas.map((quota) => (
                <option key={quota.name} value={quota.name}>
                  {quota.name} · {quota.multiplier}
                </option>
              ))}
            </select>
          </label>
          <button className="primary-button full" type="button" onClick={handleActivate}>
            <KeyRound size={17} />
            激活并生成 Key
          </button>
          {message && <p className="form-message">{message}</p>}
        </section>

        <section className="panel activation-result">
          <div className="section-heading">
            <div>
              <p className="eyebrow">激活后</p>
              <h2>个人 API Key</h2>
            </div>
            <button
              className="icon-button"
              type="button"
              title="复制 Key"
              onClick={() => onCopy(activationKey, 'new-key')}
            >
              {copied === 'new-key' ? <Check size={18} /> : <Clipboard size={18} />}
            </button>
          </div>
          <div className="endpoint-box">
            <span>仅展示一次，后续可在个人页面重置</span>
            <code>{activationKey}</code>
          </div>
          <div className="policy-list">
            <PolicyItem label="月度额度" value="3x" />
            <PolicyItem label="默认并发" value="1 路" />
            <PolicyItem label="外传处理" value="管理员暂停或重置" />
            <PolicyItem label="本机测试地址" value={apiBaseUrl} />
          </div>
        </section>
      </div>

      <section className="panel">
        <div className="section-heading">
          <div>
            <p className="eyebrow">流程</p>
            <h2>从发码到 Codex 可用</h2>
          </div>
        </div>
        <div className="flow-grid">
          <FlowStep icon={<UserPlus size={18} />} title="管理员发码" text="生成一次性登录码，发给指定成员。" />
          <FlowStep icon={<LogIn size={18} />} title="成员激活" text="输入登录码和姓名，绑定默认分组。" />
          <FlowStep icon={<PlugZap size={18} />} title="配置 Codex" text="填入 Base URL 和个人 Key。" />
          <FlowStep icon={<BarChart3 size={18} />} title="自动统计" text="按 Key 汇总请求、Token 和额度使用率。" />
        </div>
      </section>
    </section>
  )
}

function Setup({
  copied,
  onCopy,
}: {
  copied: string
  onCopy: (value: string, token: string) => void
}) {
  const codexConfig = `model_provider = "OpenAI"
model = "gpt-5.5"
review_model = "gpt-5.5"
model_reasoning_effort = "xhigh"
disable_response_storage = true

[model_providers.OpenAI]
name = "OpenAI"
base_url = "${apiBaseUrl}"
wire_api = "responses"
requires_openai_auth = true`
  const authJson = `{
  "OPENAI_API_KEY": "sk-scgk114-你的个人Key"
}`

  return (
    <section className="view-stack">
      <section className="panel setup-panel">
        <div className="section-heading">
          <div>
            <p className="eyebrow">Codex</p>
            <h2>接入地址</h2>
          </div>
          <button
            className="icon-button"
            type="button"
            title="复制地址"
            onClick={() => onCopy(apiBaseUrl, 'base-url')}
          >
            {copied === 'base-url' ? <Check size={18} /> : <Clipboard size={18} />}
          </button>
        </div>
          <div className="endpoint-box">
            <span>OpenAI compatible Base URL</span>
            <code>{apiBaseUrl}</code>
          </div>
          <div className="policy-list">
            <PolicyItem label="今天内测" value="本机 mock 后端" />
            <PolicyItem label="正式部署" value={productionApiBaseUrl} />
          </div>
        </section>

      <div className="setup-grid">
        <section className="panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">配置</p>
              <h2>Codex config.toml</h2>
            </div>
            <button
              className="icon-button"
              type="button"
              title="复制配置"
              onClick={() => onCopy(codexConfig, 'codex-config')}
            >
              {copied === 'codex-config' ? <Check size={18} /> : <Clipboard size={18} />}
            </button>
          </div>
          <pre>{codexConfig}</pre>
        </section>

        <section className="panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">成员凭据</p>
              <h2>个人 Key</h2>
            </div>
          </div>
          <div className="credential-list">
            <div>
              <KeyRound size={18} />
              <span>每位成员一个内部 Key</span>
            </div>
            <div>
              <BarChart3 size={18} />
              <span>按 Key 汇总使用率</span>
            </div>
            <div>
              <Ban size={18} />
              <span>异常调用可暂停或重置</span>
            </div>
            <div>
              <ShieldCheck size={18} />
              <span>你的上游 Key 只放服务器环境变量</span>
            </div>
          </div>
          <div className="endpoint-box compact-box">
            <span>auth.json 样板</span>
            <code>{authJson}</code>
            <button
              className="inline-copy"
              type="button"
              onClick={() => onCopy(authJson, 'auth-json')}
            >
              {copied === 'auth-json' ? '已复制' : '复制 auth.json'}
            </button>
          </div>
        </section>
      </div>

      <section className="panel">
        <div className="section-heading">
          <div>
            <p className="eyebrow">上线清单</p>
            <h2>真实可用版需要补齐</h2>
          </div>
        </div>
        <div className="check-grid">
          <CheckItem done label="订阅额度池前端样板" />
          <CheckItem done label="本地生成登录码" />
          <CheckItem done label="激活生成演示 Key" />
          <CheckItem done label="Codex 配置可复制" />
          <CheckItem done label="本地后端转发骨架" />
          <CheckItem label="配置你的 OPENAI_API_KEY" />
          <CheckItem label="跑 1-2 人真实调用" />
        </div>
        <div className="notice-band muted-notice">
          <AlertTriangle size={20} />
          <div>
            <strong>真实调用时才需要你提供上游 Key</strong>
            <span>
              朋友只使用内部 Key；你的 OpenAI API Key 保存在服务器环境变量里，不发给朋友。
            </span>
          </div>
        </div>
      </section>
    </section>
  )
}

function Monitor() {
  return (
    <section className="view-stack">
      <div className="metrics-grid">
        <MetricCard
          icon={<Activity size={19} />}
          label="整体状态"
          value="正常"
          detail="自动刷新 60 秒"
        />
        <MetricCard
          icon={<Gauge size={19} />}
          label="平均延迟"
          value="1.8s"
          detail="近 60 次请求"
        />
        <MetricCard
          icon={<Server size={19} />}
          label="可调度池"
          value="3"
          detail="主池 + 备用池"
        />
        <MetricCard
          icon={<AlertTriangle size={19} />}
          label="异常"
          value="0"
          detail="近 24 小时"
        />
      </div>

      <section className="panel">
        <div className="section-heading">
          <div>
            <p className="eyebrow">渠道状态</p>
            <h2>上游可用性</h2>
          </div>
          <span className="soft-badge">近 7 天 100%</span>
        </div>
        <DataTable
          columns={['上游池', '模型', '状态', '对话延迟', 'PING', '最近检测']}
          rows={[
            ['OpenAI Pro 主池', 'gpt-5.5', '正常', '1.6s', '54ms', '1 分钟前'],
            ['OpenAI Pro 备用池', 'gpt-5.5', '待命', '1.9s', '61ms', '1 分钟前'],
            ['OpenAI Plus 轻量池', 'gpt-5.5', '待命', '2.4s', '73ms', '3 分钟前'],
          ]}
        />
      </section>
    </section>
  )
}

function MetricCard({
  icon,
  label,
  value,
  detail,
}: {
  icon: ReactNode
  label: string
  value: string
  detail: string
}) {
  return (
    <article className="metric-card">
      <div className="metric-icon">{icon}</div>
      <span>{label}</span>
      <strong>{value}</strong>
      <p>{detail}</p>
    </article>
  )
}

function UsageChart() {
  const maxTotal = Math.max(
    ...dailyUsage.map((entry) => entry.codex + entry.chat + entry.image),
  )

  return (
    <div className="chart">
      {dailyUsage.map((entry) => {
        const total = entry.codex + entry.chat + entry.image
        const height = Math.max((total / maxTotal) * 100, 8)

        return (
          <div className="chart-column" key={entry.day}>
            <div className="bar-shell" title={`${entry.day} ${formatQuota(total)}`}>
              <div className="bar-stack" style={{ height: `${height}%` }}>
                <span className="bar-input" style={{ flexGrow: entry.codex }} />
                <span className="bar-cache" style={{ flexGrow: entry.chat }} />
                <span className="bar-output" style={{ flexGrow: entry.image }} />
              </div>
            </div>
            <span>{entry.day.slice(3)}</span>
          </div>
        )
      })}
    </div>
  )
}

function ChartLegend() {
  return (
    <div className="chart-legend">
      <span><i className="legend-dot blue" />Codex</span>
      <span><i className="legend-dot green" />研究问答</span>
      <span><i className="legend-dot amber" />图像任务</span>
    </div>
  )
}

function PoolCard({ account }: { account: PoolAccount }) {
  const percent = Math.min((account.used / account.capacity) * 100, 100)
  const statusText = {
    normal: '正常',
    standby: '待命',
    limited: '受限',
  }[account.status]

  return (
    <article className="member-card">
      <div className="member-card-top">
        <div className="avatar">{account.plan.slice(0, 1)}</div>
        <div>
          <h3>{account.name}</h3>
          <p>{account.plan} · 延迟 {account.latency}</p>
        </div>
        <span className={account.status === 'normal' ? 'tag ok' : 'tag'}>
          {statusText}
        </span>
      </div>
      <div className="quota-track small">
        <span style={{ width: `${percent}%` }} />
      </div>
      <div className="member-stats">
        <span>总额 {formatQuota(account.capacity)}</span>
        <span>已用 {formatQuota(account.used)}</span>
        <span>{Math.round(percent)}%</span>
      </div>
      <p className="muted-copy">{account.note}</p>
    </article>
  )
}

function MemberCard({ member, role }: { member: Member; role: Role }) {
  const remaining = Math.max(member.quotaLimit - member.quotaUsed, 0)
  const percent = Math.min(
    (member.quotaUsed / Math.max(member.quotaLimit, 1)) * 100,
    100,
  )
  const shouldWarn = percent >= warningPercent

  return (
    <article className="member-card">
      <div className="member-card-top">
        <div className="avatar">{member.name.slice(-1)}</div>
        <div>
          <h3>{member.name}</h3>
          <p>{member.role} · 最近 {member.lastSeen}</p>
        </div>
        <span className={member.status === 'active' ? 'tag ok' : 'tag'}>
          {member.status === 'active' ? '启用' : '暂停'}
        </span>
      </div>
      <div className="key-row">
        <LockKeyhole size={16} />
        <code>{role === 'admin' ? member.keyLabel : 'sk-scgk114-***'}</code>
      </div>
      <div className="quota-track small">
        <span style={{ width: `${percent}%` }} />
      </div>
      <div className="member-stats">
        <span>{member.group}</span>
        <span>已用 {formatQuota(member.quotaUsed)}</span>
        <span>剩余 {formatQuota(remaining)}</span>
        <span>{member.requestCount} 次</span>
      </div>
      <div className="inline-actions">
        <button type="button">暂停</button>
        <button type="button">重置 Key</button>
        <button type="button">调整额度</button>
      </div>
      {shouldWarn && <p className="muted-copy warn-copy">接近个人额度上限</p>}
    </article>
  )
}

function InviteCard({
  copied,
  invite,
  onCopy,
}: {
  copied: string
  invite: InviteCode
  onCopy: (value: string, token: string) => void
}) {
  const statusText = {
    unused: '未使用',
    used: '已使用',
    disabled: '已作废',
  }[invite.status]
  const canCopy = invite.status === 'unused'

  return (
    <article className="invite-card">
      <div>
        <strong>{invite.code}</strong>
        <span className={`tag ${invite.status === 'used' ? 'ok' : ''}`}>
          {statusText}
        </span>
      </div>
      <p>{invite.owner}</p>
      <small>
        分组 {invite.group} · 创建 {invite.createdAt} · 使用 {invite.usedAt}
      </small>
      {canCopy && (
        <button
          className="inline-copy"
          type="button"
          onClick={() => onCopy(invite.code, `invite-${invite.code}`)}
        >
          {copied === `invite-${invite.code}` ? '已复制' : '复制登录码'}
        </button>
      )}
    </article>
  )
}

function PolicyItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="policy-item">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  )
}

function FlowStep({
  icon,
  title,
  text,
}: {
  icon: ReactNode
  title: string
  text: string
}) {
  return (
    <article className="flow-step">
      <div className="flow-icon">{icon}</div>
      <h3>{title}</h3>
      <p>{text}</p>
      <ArrowRight className="flow-arrow" size={18} />
    </article>
  )
}

function CheckItem({ done, label }: { done?: boolean; label: string }) {
  return (
    <div className={done ? 'check-item done' : 'check-item'}>
      {done ? <Check size={16} /> : <FileText size={16} />}
      <span>{label}</span>
    </div>
  )
}

function DataTable({
  columns,
  rows,
}: {
  columns: string[]
  rows: string[][]
}) {
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            {columns.map((column) => (
              <th key={column}>{column}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.join('-')}>
              {row.map((cell) => (
                <td key={cell}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function formatQuota(value: number) {
  return `${Math.max(value, 0).toFixed(value % 1 === 0 ? 0 : 1)}x`
}

function createInviteCode(existing: InviteCode[]) {
  const existingCodes = new Set(existing.map((invite) => invite.code))
  let code = ''

  do {
    code = `SCGK-${randomChunk(4)}`
  } while (existingCodes.has(code))

  return code
}

function createDemoKey(seed: string) {
  return `sk-scgk114-${seed.toLowerCase()}-${randomChunk(16).toLowerCase()}`
}

function maskKey(key: string) {
  return `${key.slice(0, 15)}...${key.slice(-4)}`
}

function randomChunk(length: number) {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  const bytes = new Uint8Array(length)

  window.crypto.getRandomValues(bytes)

  return Array.from(bytes, (byte) => alphabet[byte % alphabet.length]).join('')
}

function getViewTitle(view: View) {
  const titles = {
    overview: '订阅额度总览',
    pool: '额度池与分组',
    members: '成员与登录码',
    activation: '成员激活',
    setup: 'Codex 接入',
    monitor: '状态监控',
  }

  return titles[view]
}

function getViewFromHash(): View {
  const hash = window.location.hash.replace('#', '')
  const views: View[] = ['overview', 'pool', 'members', 'activation', 'setup', 'monitor']

  return views.includes(hash as View) ? (hash as View) : 'overview'
}

export default App
